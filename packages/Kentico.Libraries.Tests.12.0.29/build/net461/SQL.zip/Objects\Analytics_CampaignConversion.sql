SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_CampaignConversion](
	[CampaignConversionID] [int] IDENTITY(1,1) NOT NULL,
	[CampaignConversionGuid] [uniqueidentifier] NOT NULL,
	[CampaignConversionLastModified] [datetime2](7) NOT NULL,
	[CampaignConversionDisplayName] [nvarchar](100) NOT NULL,
	[CampaignConversionName] [nvarchar](100) NOT NULL,
	[CampaignConversionCampaignID] [int] NOT NULL,
	[CampaignConversionOrder] [int] NOT NULL,
	[CampaignConversionActivityType] [nvarchar](250) NOT NULL,
	[CampaignConversionHits] [int] NOT NULL,
	[CampaignConversionItemID] [int] NULL,
	[CampaignConversionValue] [float] NOT NULL,
	[CampaignConversionIsFunnelStep] [bit] NOT NULL,
	[CampaignConversionURL] [nvarchar](max) NULL,
 CONSTRAINT [PK_Analytics_CampaignConversion] PRIMARY KEY CLUSTERED 
(
	[CampaignConversionID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_Analytics_CampaignConversion_CampaignConversionCampaignID] ON [dbo].[Analytics_CampaignConversion]
(
	[CampaignConversionCampaignID] ASC
)
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CampaignConversionGuid]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [CampaignConversionLastModified]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionDisplayName]  DEFAULT (N'') FOR [CampaignConversionDisplayName]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionName]  DEFAULT (N'') FOR [CampaignConversionName]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionCampaignID]  DEFAULT ((0)) FOR [CampaignConversionCampaignID]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionOrder]  DEFAULT ((0)) FOR [CampaignConversionOrder]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionActivityType]  DEFAULT (N'') FOR [CampaignConversionActivityType]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionHits]  DEFAULT ((0)) FOR [CampaignConversionHits]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionValue]  DEFAULT ((0)) FOR [CampaignConversionValue]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] ADD  CONSTRAINT [DEFAULT_Analytics_CampaignConversion_CampaignConversionIsFunnelStep]  DEFAULT ((0)) FOR [CampaignConversionIsFunnelStep]
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_CampaignConversion_CampaignConversionCampaignID_Analytics_Campaign] FOREIGN KEY([CampaignConversionCampaignID])
REFERENCES [dbo].[Analytics_Campaign] ([CampaignID])
GO
ALTER TABLE [dbo].[Analytics_CampaignConversion] CHECK CONSTRAINT [FK_Analytics_CampaignConversion_CampaignConversionCampaignID_Analytics_Campaign]
GO
